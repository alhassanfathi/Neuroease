// Seed data for the clinic prototype. Realistic-looking but fictional.
// All German labels live alongside English fallbacks where useful.

export type EmgFile = {
  id: string;
  name: string;
  kind: "EMG" | "NLG" | "MRT" | "Bericht";
  date: string; // ISO
  sizeKb: number;
};

export type RehabStep = {
  id: string;
  title: string;
  description: string;
  frequency: string; // e.g. "3x täglich"
  done: boolean;
};

export type Message = {
  id: string;
  from: "doctor" | "patient";
  text: string;
  at: string; // ISO
};

export type Appointment = {
  id: string;
  date: string; // ISO
  type: string; // "EMG-Kontrolle", "Verlaufsgespräch"…
  location: string;
};

export type Patient = {
  id: string;
  firstName: string;
  lastName: string;
  birthDate: string; // ISO
  insurance: string;
  insuranceNumber: string;
  email: string;
  phone: string;
  diagnosis: {
    primary: { code: string; label: string };
    secondary: { code: string; label: string }[];
  };
  status: "Aktiv" | "Abgeschlossen" | "In Beobachtung";
  lastVisit: string;
  nextVisit?: string;
  files: EmgFile[];
  rehab: RehabStep[];
  messages: Message[];
  appointments: Appointment[];
  notes: string;
};

export const patients: Patient[] = [
  {
    id: "p-001",
    firstName: "Lena",
    lastName: "Hofmann",
    birthDate: "1991-03-12",
    insurance: "AOK Bayern",
    insuranceNumber: "A123456789",
    email: "lena.hofmann@example.de",
    phone: "+49 170 1234567",
    diagnosis: {
      primary: { code: "G56.0", label: "Karpaltunnelsyndrom rechts" },
      secondary: [{ code: "M54.2", label: "Zervikalgie" }],
    },
    status: "Aktiv",
    lastVisit: "2026-04-10",
    nextVisit: "2026-05-02",
    files: [
      { id: "f1", name: "EMG_Median_2026-04-10.pdf", kind: "EMG", date: "2026-04-10", sizeKb: 412 },
      { id: "f2", name: "NLG_Befund_2026-04-10.pdf", kind: "NLG", date: "2026-04-10", sizeKb: 318 },
    ],
    rehab: [
      {
        id: "r1",
        title: "Nervengleitübungen Medianus",
        description: "Sanfte Mobilisation des N. medianus, jede Bewegung 10 Wiederholungen.",
        frequency: "3x täglich",
        done: true,
      },
      {
        id: "r2",
        title: "Handgelenk-Schiene nachts",
        description: "Neutrale Schienenstellung über Nacht für 4 Wochen.",
        frequency: "Jede Nacht",
        done: true,
      },
      {
        id: "r3",
        title: "Kräftigung Daumenballen",
        description: "Mit Therapieknete 5 Minuten kneten, Fokus auf Opposition.",
        frequency: "2x täglich",
        done: false,
      },
    ],
    messages: [
      {
        id: "m1",
        from: "doctor",
        text: "Guten Tag Frau Hofmann, Ihre EMG-Befunde habe ich hochgeladen. Bitte beginnen Sie mit den Übungen wie besprochen.",
        at: "2026-04-10T14:20:00Z",
      },
      {
        id: "m2",
        from: "patient",
        text: "Vielen Dank, Herr Doktor. Die Übungen tun gut, das Kribbeln nachts ist schon weniger.",
        at: "2026-04-15T09:05:00Z",
      },
    ],
    appointments: [
      {
        id: "a1",
        date: "2026-05-02T09:30:00Z",
        type: "EMG-Kontrolle",
        location: "Praxis Dr. Weber, Raum 3",
      },
    ],
    notes:
      "Patientin spricht gut auf konservative Therapie an. EMG-Kontrolle in 4 Wochen, ggf. Vorstellung Handchirurgie.",
  },
  {
    id: "p-002",
    firstName: "Tobias",
    lastName: "Krüger",
    birthDate: "1968-09-04",
    insurance: "Techniker Krankenkasse",
    insuranceNumber: "T987654321",
    email: "tobias.krueger@example.de",
    phone: "+49 151 7654321",
    diagnosis: {
      primary: { code: "G35", label: "Multiple Sklerose, schubförmig" },
      secondary: [{ code: "R26.8", label: "Gangstörung" }],
    },
    status: "In Beobachtung",
    lastVisit: "2026-03-28",
    nextVisit: "2026-04-29",
    files: [
      { id: "f3", name: "MRT_Schaedel_2026-03-20.pdf", kind: "MRT", date: "2026-03-20", sizeKb: 2104 },
      { id: "f4", name: "Verlaufsbericht_Q1.pdf", kind: "Bericht", date: "2026-03-28", sizeKb: 188 },
    ],
    rehab: [
      {
        id: "r4",
        title: "Gleichgewichtstraining",
        description: "Einbeinstand mit offenen, dann geschlossenen Augen, je 30 Sekunden.",
        frequency: "Täglich",
        done: false,
      },
      {
        id: "r5",
        title: "Aerobes Ausdauertraining",
        description: "Ergometer 20 Minuten in moderater Intensität.",
        frequency: "3x pro Woche",
        done: false,
      },
    ],
    messages: [
      {
        id: "m3",
        from: "doctor",
        text: "Herr Krüger, der MRT-Verlauf ist stabil. Wir setzen die aktuelle Therapie fort.",
        at: "2026-03-28T11:00:00Z",
      },
    ],
    appointments: [
      {
        id: "a2",
        date: "2026-04-29T10:00:00Z",
        type: "Verlaufsgespräch",
        location: "Praxis Dr. Weber, Raum 1",
      },
    ],
    notes: "Stabiler Verlauf seit Januar. Weiter Tysabri-Infusionen alle 4 Wochen.",
  },
  {
    id: "p-003",
    firstName: "Ayşe",
    lastName: "Demir",
    birthDate: "2002-07-21",
    insurance: "Barmer",
    insuranceNumber: "B456789123",
    email: "ayse.demir@example.de",
    phone: "+49 162 1122334",
    diagnosis: {
      primary: { code: "G43.1", label: "Migräne mit Aura" },
      secondary: [],
    },
    status: "Aktiv",
    lastVisit: "2026-04-18",
    files: [
      { id: "f5", name: "Kopfschmerz_Tagebuch_April.pdf", kind: "Bericht", date: "2026-04-18", sizeKb: 96 },
    ],
    rehab: [
      {
        id: "r6",
        title: "Trigger-Tagebuch",
        description: "Schlaf, Ernährung und Stress dokumentieren — empfohlen über die NeuroEase Study App.",
        frequency: "Täglich",
        done: true,
      },
      {
        id: "r7",
        title: "Entspannungsübungen",
        description: "Progressive Muskelentspannung nach Jacobson, geführte Audio-Sitzung.",
        frequency: "Abends",
        done: false,
      },
    ],
    messages: [],
    appointments: [],
    notes:
      "Studentin — empfohlen, NeuroEase Study für Fokus- und Sensorik-Tools zu nutzen, ergänzt das Migräne-Management.",
  },
  {
    id: "p-004",
    firstName: "Markus",
    lastName: "Schneider",
    birthDate: "1955-11-30",
    insurance: "AOK Plus",
    insuranceNumber: "P321654987",
    email: "markus.schneider@example.de",
    phone: "+49 173 5566778",
    diagnosis: {
      primary: { code: "G20", label: "Morbus Parkinson" },
      secondary: [{ code: "F32.1", label: "Mittelgradige depressive Episode" }],
    },
    status: "Aktiv",
    lastVisit: "2026-04-05",
    nextVisit: "2026-05-10",
    files: [
      { id: "f6", name: "EMG_UEX_2026-04-05.pdf", kind: "EMG", date: "2026-04-05", sizeKb: 502 },
    ],
    rehab: [
      {
        id: "r8",
        title: "Großräumige Bewegung (LSVT BIG)",
        description: "Übungsblock 1 — siehe Video. Fokus auf Schrittlänge.",
        frequency: "5x pro Woche",
        done: false,
      },
    ],
    messages: [
      {
        id: "m4",
        from: "patient",
        text: "Guten Morgen, das neue Medikament macht mich tagsüber sehr müde. Ist das normal?",
        at: "2026-04-20T07:50:00Z",
      },
    ],
    appointments: [
      {
        id: "a3",
        date: "2026-05-10T15:00:00Z",
        type: "Medikamentenanpassung",
        location: "Telemedizin",
      },
    ],
    notes: "Neue Medikation seit 2026-04-05. Reaktion in 2 Wochen kontrollieren.",
  },
];

export function findPatient(id: string) {
  return patients.find((p) => p.id === id);
}

export function ageFromBirth(iso: string) {
  const b = new Date(iso);
  const t = new Date();
  let a = t.getFullYear() - b.getFullYear();
  const m = t.getMonth() - b.getMonth();
  if (m < 0 || (m === 0 && t.getDate() < b.getDate())) a--;
  return a;
}

export function formatDateDe(iso: string, withTime = false) {
  const d = new Date(iso);
  const date = d.toLocaleDateString("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" });
  if (!withTime) return date;
  const time = d.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" });
  return `${date} · ${time}`;
}
