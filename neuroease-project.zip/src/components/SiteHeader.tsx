import { Link, useLocation } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { Menu, X, Stethoscope, Heart } from "lucide-react";
import neuronLogo from "@/assets/neuron-logo.png";

type NavItem = { to: string; label: string };

const studyItems: NavItem[] = [
  { to: "/", label: "Start" },
  { to: "/focus", label: "Fokus" },
  { to: "/tasks", label: "Aufgaben" },
  { to: "/read", label: "Lesen" },
  { to: "/checkin", label: "Check-in" },
];

const clinicItems: NavItem[] = [
  { to: "/klinik", label: "Übersicht" },
  { to: "/klinik/patienten", label: "Patient" },
  { to: "/klinik/termine", label: "Termine" },
  { to: "/klinik/nachrichten", label: "Nachrichten" },
];

export function SiteHeader() {
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const inClinic = pathname.startsWith("/klinik");
  const items = inClinic ? clinicItems : studyItems;

  return (
    <header className="w-full max-w-[1280px] mx-auto px-6 md:px-8 py-6 flex justify-between items-center relative z-30 gap-4">
      <Link to="/" className="flex items-center gap-2.5 group shrink-0">
        <span className="size-9 rounded-xl bg-card flex items-center justify-center ring-1 ring-border shadow-soft">
          <img src={neuronLogo} alt="NeuroEase Logo" width={512} height={512} className="size-7 object-contain" />
        </span>
        <span className="flex flex-col leading-tight whitespace-nowrap">
          <span className="text-lg font-semibold tracking-tight text-ink">
            NeuroEase
            
          </span>
          <span className="text-[10px] uppercase tracking-[0.18em] text-ink-muted">
            by MSH — Mia Suachn Hüf
          </span>
        </span>
      </Link>

      {/* Product switcher */}
      <div className="hidden lg:flex items-center gap-1 bg-card rounded-full p-1 ring-1 ring-tray-border shadow-soft">
        <Link
          to="/klinik"
          className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center gap-1.5 transition-colors ${
            inClinic ? "bg-ink text-primary-foreground" : "text-ink-muted hover:text-ink"
          }`}
        >
          <Stethoscope className="size-3.5" />
          Praxis
        </Link>
        <Link
          to="/msh"
          className={`px-3 py-1.5 rounded-full text-xs font-medium flex items-center gap-1.5 transition-colors ${
            pathname.startsWith("/msh") ? "bg-ink text-primary-foreground" : "text-ink-muted hover:text-ink"
          }`}
        >
          <Heart className="size-3.5" />
          MSH
        </Link>
      </div>

      {/* Section nav */}
      <nav className="hidden md:flex items-center gap-1 bg-card rounded-full p-1.5 ring-1 ring-tray-border shadow-soft">
        {items.map((item) => {
          const active =
            item.to === "/klinik"
              ? pathname === "/klinik"
              : item.to === "/"
                ? pathname === "/"
                : pathname.startsWith(item.to);
          return (
            <Link
              key={item.to}
              to={item.to}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                active
                  ? "bg-ink text-primary-foreground"
                  : "text-ink-muted hover:text-ink hover:bg-muted"
              }`}
            >
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="flex items-center gap-2">
        <Link
          to="/login"
          className={`hidden sm:inline-flex px-4 py-2 rounded-full text-sm font-medium transition-colors ${
            pathname.startsWith("/login")
              ? "bg-ink text-primary-foreground"
              : "bg-card text-ink-muted ring-1 ring-tray-border hover:text-ink"
          }`}
        >
          Login
        </Link>

        {/* Mobile trigger */}
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-label="Menü"
          aria-expanded={open}
          className="md:hidden size-10 rounded-full bg-card ring-1 ring-tray-border flex items-center justify-center text-ink"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {open && (
        <div className="absolute top-full right-6 mt-2 md:hidden bg-card rounded-2xl ring-1 ring-tray-border shadow-pebble p-2 flex flex-col min-w-[200px]">
          <div className="flex gap-1 p-1 bg-background rounded-xl mb-1">
            <Link
              to="/klinik"
              className={`flex-1 text-center px-3 py-1.5 rounded-lg text-xs font-medium ${
                inClinic ? "bg-ink text-primary-foreground" : "text-ink-muted"
              }`}
            >
              Praxis
            </Link>
            <Link
              to="/msh"
              className={`flex-1 text-center px-3 py-1.5 rounded-lg text-xs font-medium ${
                pathname.startsWith("/msh") ? "bg-ink text-primary-foreground" : "text-ink-muted"
              }`}
            >
              MSH
            </Link>
          </div>
          {items.map((item) => {
            const active = pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`px-4 py-2.5 rounded-xl text-sm font-medium ${
                  active ? "bg-ink text-primary-foreground" : "text-ink-muted hover:bg-muted"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
          <Link
            to="/login"
            className={`px-4 py-2.5 rounded-xl text-sm font-medium ${
              pathname.startsWith("/login") ? "bg-ink text-primary-foreground" : "text-ink-muted hover:bg-muted"
            }`}
          >
            Login
          </Link>
        </div>
      )}
    </header>
  );
}
