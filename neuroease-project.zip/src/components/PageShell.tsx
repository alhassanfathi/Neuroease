import type { ReactNode } from "react";
import { SiteHeader } from "./SiteHeader";

export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-dvh bg-background text-foreground antialiased flex flex-col">
      <SiteHeader />
      <main className="flex-1 w-full max-w-[1280px] mx-auto px-6 md:px-8 pb-20">{children}</main>
      <footer className="w-full max-w-[1280px] mx-auto px-6 md:px-8 py-10 text-sm text-ink-muted flex flex-col md:flex-row justify-between gap-3 border-t border-tray-border">
        <span>
          NeuroEase · Ein Projekt von <strong className="text-ink font-medium">MSH — Mia Suachn Hüf e.V.</strong>
        </span>
        <span>Gemeinnützig · Für Menschen, die Hilfe suchen.</span>
      </footer>
    </div>
  );
}
