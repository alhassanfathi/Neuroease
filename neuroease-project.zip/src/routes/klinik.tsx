import { createFileRoute, Link, Outlet, useLocation } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { LayoutDashboard, Users, Calendar, MessageSquare } from "lucide-react";

export const Route = createFileRoute("/klinik")({
  component: KlinikLayout,
});

const sidebar = [
  { to: "/klinik" as const, label: "Übersicht", icon: LayoutDashboard, exact: true },
  { to: "/klinik/patienten" as const, label: "Patient", icon: Users },
  { to: "/klinik/termine" as const, label: "Termine", icon: Calendar },
  { to: "/klinik/nachrichten" as const, label: "Nachrichten", icon: MessageSquare },
];

function KlinikLayout() {
  const { pathname } = useLocation();
  return (
    <PageShell>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-4">
        <aside className="lg:col-span-3 lg:sticky lg:top-6 lg:self-start">
          <div className="bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble p-4 flex flex-col gap-1">
            <div className="px-3 py-2 mb-1">
              <div className="text-xs uppercase tracking-widest text-ink-muted">Praxis</div>
              <div className="text-sm font-medium text-ink mt-1">Dr. med. Anja Weber</div>
              <div className="text-xs text-ink-muted">Fachärztin für Neurologie · München</div>
            </div>
            {sidebar.map((s) => {
              const active = s.exact ? pathname === s.to : pathname.startsWith(s.to);
              return (
                <Link
                  key={s.to}
                  to={s.to}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors ${
                    active
                      ? "bg-ink text-primary-foreground"
                      : "text-ink-muted hover:text-ink hover:bg-muted"
                  }`}
                >
                  <s.icon className="size-4" />
                  {s.label}
                </Link>
              );
            })}
          </div>
        </aside>
        <section className="lg:col-span-9">
          <Outlet />
        </section>
      </div>
    </PageShell>
  );
}
