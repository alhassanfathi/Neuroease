import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { useState } from "react";
import { Plus, Check, X } from "lucide-react";

export const Route = createFileRoute("/tasks")({
  component: TasksPage,
  head: () => ({
    meta: [
      { title: "Task Untangling — NeuroEase" },
      {
        name: "description",
        content: "Break overwhelming assignments into the smallest possible steps.",
      },
    ],
  }),
});

type Step = { id: string; text: string; done: boolean };
type Task = { id: string; title: string; steps: Step[] };

const seed: Task[] = [
  {
    id: "t1",
    title: "Environmental Science essay",
    steps: [
      { id: "s1", text: "Open lecture notes to page 42", done: true },
      { id: "s2", text: "Outline three main arguments", done: false },
      { id: "s3", text: "Write opening sentence", done: false },
      { id: "s4", text: "Add one supporting source", done: false },
    ],
  },
];

function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>(seed);
  const [activeId, setActiveId] = useState<string>(seed[0].id);
  const [newStep, setNewStep] = useState("");
  const [newTask, setNewTask] = useState("");

  const active = tasks.find((t) => t.id === activeId);

  const toggleStep = (sid: string) => {
    setTasks((ts) =>
      ts.map((t) =>
        t.id === activeId
          ? { ...t, steps: t.steps.map((s) => (s.id === sid ? { ...s, done: !s.done } : s)) }
          : t,
      ),
    );
  };

  const addStep = () => {
    if (!newStep.trim() || !active) return;
    setTasks((ts) =>
      ts.map((t) =>
        t.id === activeId
          ? { ...t, steps: [...t.steps, { id: crypto.randomUUID(), text: newStep, done: false }] }
          : t,
      ),
    );
    setNewStep("");
  };

  const addTask = () => {
    if (!newTask.trim()) return;
    const id = crypto.randomUUID();
    setTasks((ts) => [...ts, { id, title: newTask, steps: [] }]);
    setActiveId(id);
    setNewTask("");
  };

  const currentStep = active?.steps.find((s) => !s.done);

  return (
    <PageShell>
      <section className="pt-8 md:pt-12 pb-12 flex flex-col gap-3">
        <span className="text-sm tracking-widest uppercase text-ink-muted">Task Untangling</span>
        <h1 className="text-4xl md:text-5xl font-medium tracking-tight text-ink">
          One small step. Then the next.
        </h1>
        <p className="text-ink-muted max-w-[55ch] leading-relaxed">
          Big assignments shrink when you cut them up. Add a task, break it into tiny steps, and
          we'll only show you the next one.
        </p>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Tasks list */}
        <aside className="lg:col-span-4 bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble p-6 flex flex-col gap-4">
          <h2 className="text-sm font-medium uppercase tracking-widest text-ink-muted">
            Your tasks
          </h2>
          <div className="flex flex-col gap-2">
            {tasks.map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveId(t.id)}
                className={`text-left px-4 py-3 rounded-2xl transition-colors ${
                  activeId === t.id
                    ? "bg-ink text-primary-foreground"
                    : "bg-background hover:bg-muted text-ink"
                }`}
              >
                <div className="font-medium truncate">{t.title}</div>
                <div
                  className={`text-xs mt-1 ${activeId === t.id ? "opacity-70" : "text-ink-muted"}`}
                >
                  {t.steps.filter((s) => s.done).length} of {t.steps.length} done
                </div>
              </button>
            ))}
          </div>
          <div className="flex gap-2 pt-2 border-t border-tray-border">
            <input
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addTask()}
              placeholder="New task…"
              className="flex-1 px-4 py-2.5 rounded-full bg-background ring-1 ring-tray-border text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              onClick={addTask}
              className="size-10 rounded-full bg-ink text-primary-foreground flex items-center justify-center"
              aria-label="Add task"
            >
              <Plus className="size-4" />
            </button>
          </div>
        </aside>

        {/* Detail */}
        <section className="lg:col-span-8 bg-card rounded-3xl ring-1 ring-tray-border shadow-tray p-8 flex flex-col gap-8">
          {active ? (
            <>
              <div>
                <h2 className="text-3xl font-medium tracking-tight text-ink">{active.title}</h2>
                {currentStep && (
                  <div className="mt-6 p-5 rounded-2xl bg-sage-soft/60 ring-1 ring-sage/20">
                    <div className="text-xs uppercase tracking-widest text-ink-muted mb-2">
                      Just this, right now
                    </div>
                    <div className="text-xl text-ink font-medium">{currentStep.text}</div>
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-2">
                {active.steps.map((s) => (
                  <label
                    key={s.id}
                    className="flex items-center gap-4 p-4 rounded-2xl bg-background hover:bg-muted cursor-pointer transition-colors"
                  >
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        toggleStep(s.id);
                      }}
                      className={`shrink-0 size-6 rounded-md flex items-center justify-center transition-colors ${
                        s.done
                          ? "bg-sage text-white"
                          : "bg-card ring-1 ring-tray-border"
                      }`}
                      aria-label={s.done ? "Mark undone" : "Mark done"}
                    >
                      {s.done && <Check className="size-4" />}
                    </button>
                    <span
                      className={
                        s.done
                          ? "line-through text-ink-muted"
                          : "text-ink"
                      }
                    >
                      {s.text}
                    </span>
                  </label>
                ))}
              </div>

              <div className="flex gap-2">
                <input
                  value={newStep}
                  onChange={(e) => setNewStep(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addStep()}
                  placeholder="Add a tiny next step…"
                  className="flex-1 px-5 py-3 rounded-full bg-background ring-1 ring-tray-border focus:outline-none focus:ring-2 focus:ring-ring"
                />
                <button
                  onClick={addStep}
                  className="px-5 py-3 rounded-full bg-ink text-primary-foreground font-medium flex items-center gap-2"
                >
                  <Plus className="size-4" /> Add step
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center text-ink-muted py-20">
              <X className="size-5 mr-2" /> No task selected
            </div>
          )}
        </section>
      </div>
    </PageShell>
  );
}
