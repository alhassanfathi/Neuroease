import { createFileRoute, Link } from "@tanstack/react-router";
import { patients, formatDateDe } from "@/lib/clinic-data";
import { Users, Calendar, FileUp, MessageSquare, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/klinik/")({
  component: KlinikIndex,
  head: () => ({ meta: [{ title: "Praxis · Übersicht — NeuroEase" }] }),
});

function KlinikIndex() {
  const upcoming = patients
    .flatMap((p) => p.appointments.map((a) => ({ ...a, patient: p })))
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 3);

  const recentMessages = patients
    .flatMap((p) => p.messages.map((m) => ({ ...m, patient: p })))
    .sort((a, b) => b.at.localeCompare(a.at))
    .slice(0, 3);

  const stats = [
    { label: "Aktive Patient", value: patients.filter((p) => p.status === "Aktiv").length, icon: Users },
    { label: "Termine diese Woche", value: upcoming.length, icon: Calendar },
    { label: "Hochgeladene Befunde", value: patients.reduce((n, p) => n + p.files.length, 0), icon: FileUp },
    { label: "Offene Nachrichten", value: 1, icon: MessageSquare },
  ];

  return (
    <div className="flex flex-col gap-8">
      <header className="flex flex-col gap-2">
        <span className="text-sm tracking-widest uppercase text-ink-muted">Übersicht</span>
        <h1 className="text-3xl md:text-4xl font-medium tracking-tight text-ink">
          Guten Tag, Dr. Weber.
        </h1>
        <p className="text-ink-muted">Heute ist {formatDateDe(new Date().toISOString())}.</p>
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <div
            key={s.label}
            className="bg-card rounded-2xl ring-1 ring-tray-border p-5 flex flex-col gap-3"
          >
            <s.icon className="size-4 text-ink-muted" />
            <div>
              <div className="text-3xl font-medium text-ink tabular-nums">{s.value}</div>
              <div className="text-xs text-ink-muted mt-1">{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble p-6 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-ink">Nächste Termine</h2>
            <Link to="/klinik/termine" className="text-sm text-ink-muted hover:text-ink">
              Alle anzeigen
            </Link>
          </div>
          <div className="flex flex-col divide-y divide-tray-border">
            {upcoming.map((a) => (
              <Link
                key={a.id}
                to="/klinik/patienten/$id"
                params={{ id: a.patient.id }}
                className="py-3 flex items-center justify-between gap-3 hover:opacity-80"
              >
                <div className="min-w-0">
                  <div className="font-medium text-ink truncate">
                    {a.patient.firstName} {a.patient.lastName}
                  </div>
                  <div className="text-sm text-ink-muted truncate">
                    {a.type} · {a.location}
                  </div>
                </div>
                <div className="text-sm text-ink-muted text-right shrink-0">
                  {formatDateDe(a.date, true)}
                </div>
              </Link>
            ))}
          </div>
        </section>

        <section className="bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble p-6 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-ink">Letzte Nachrichten</h2>
            <Link to="/klinik/nachrichten" className="text-sm text-ink-muted hover:text-ink">
              Posteingang
            </Link>
          </div>
          <div className="flex flex-col divide-y divide-tray-border">
            {recentMessages.map((m) => (
              <Link
                key={m.id}
                to="/klinik/patienten/$id"
                params={{ id: m.patient.id }}
                className="py-3 flex items-start gap-3 hover:opacity-80"
              >
                <div
                  className={`mt-1 size-2 rounded-full shrink-0 ${
                    m.from === "patient" ? "bg-clay" : "bg-sage"
                  }`}
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium text-ink truncate">
                      {m.patient.firstName} {m.patient.lastName}
                    </span>
                    <span className="text-xs text-ink-muted shrink-0">
                      {formatDateDe(m.at)}
                    </span>
                  </div>
                  <p className="text-sm text-ink-muted line-clamp-2 mt-0.5">{m.text}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>

      <Link
        to="/klinik/patienten"
        className="bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble p-6 flex items-center justify-between hover:bg-muted transition-colors"
      >
        <div>
          <div className="text-lg font-medium text-ink">Alle Patient verwalten</div>
          <div className="text-sm text-ink-muted">Profile, Diagnosen, Befunde und Reha-Pläne</div>
        </div>
        <ArrowRight className="size-5 text-ink-muted" />
      </Link>
    </div>
  );
}
