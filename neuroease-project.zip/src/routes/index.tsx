import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { Stethoscope, GraduationCap, ArrowRight, FileText, Activity, Heart } from "lucide-react";
import heroImage from "@/assets/hero-neural.jpg";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "NeuroEase — Neurologie & Studium, leise verbunden" },
      {
        name: "description",
        content:
          "Zwei Werkzeuge, die zusammenarbeiten: NeuroEase für Facharztärzte und NeuroEase Study für neurodivergente Studierende.",
      },
      { property: "og:title", content: "NeuroEase — Neurologie & Studium" },
      {
        property: "og:description",
        content: "Befunde teilen, Reha begleiten, Studium meistern — in einer ruhigen Oberfläche.",
      },
    ],
  }),
});

function Index() {
  return (
    <PageShell>
      {/* Hero */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center pt-8 md:pt-12 pb-20 md:pb-28">
        <div className="lg:col-span-6 flex flex-col gap-7">
          <div className="px-4 py-1.5 rounded-full bg-card ring-1 ring-tray-border text-sm text-ink-muted shadow-soft self-start inline-flex items-center gap-2">
            <Heart className="size-3.5 text-accent" />
            Ein gemeinnütziges Projekt von MSH — Mia Suachn Hüf
          </div>
          <h1 className="text-5xl md:text-[4rem] lg:text-[4.5rem] tracking-tight leading-[1.05] font-medium text-balance">
            Neurologie,
            <br />
            in Ruhe verbunden.
          </h1>
          <p className="text-lg md:text-xl text-ink-muted leading-relaxed max-w-[52ch] text-pretty">
            NeuroEase wird von <strong className="text-ink font-medium">MSH — Mia Suachn Hüf</strong>{" "}
            getragen, einer gemeinnützigen Organisation für Menschen, die Hilfe suchen. Zwei
            Werkzeuge arbeiten Hand in Hand: eine Plattform für Facharztärzte und ein ruhiger
            Studium-Begleiter für neurodivergente Studierende.
          </p>
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Link
              to="/klinik"
              className="px-7 py-3.5 rounded-full bg-ink text-primary-foreground font-medium hover:opacity-90 transition-opacity shadow-soft inline-flex items-center gap-2"
            >
              <Stethoscope className="size-4" />
              Praxis öffnen
            </Link>
            <Link
              to="/focus"
              className="px-7 py-3.5 rounded-full bg-card text-ink font-medium ring-1 ring-tray-border hover:bg-muted transition-colors inline-flex items-center gap-2"
            >
              <GraduationCap className="size-4" />
              Study entdecken
            </Link>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="rounded-[2.5rem] overflow-hidden ring-1 ring-tray-border shadow-tray bg-card">
            <img
              src={heroImage}
              alt="Leuchtendes Neuron verbunden mit Schaltkreisen — Symbol für Neurologie und Technologie"
              width={1536}
              height={1024}
              className="w-full h-auto block"
            />
          </div>
        </div>
      </section>

      {/* Two products */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Link
          to="/klinik"
          className="group bg-card rounded-[2rem] ring-1 ring-tray-border shadow-pebble p-8 md:p-10 flex flex-col gap-6 hover:-translate-y-0.5 hover:shadow-tray transition-all"
        >
          <div className="size-12 rounded-2xl bg-clay-soft text-clay flex items-center justify-center">
            <Stethoscope className="size-5" />
          </div>
          <div className="flex flex-col gap-3 flex-1">
            <span className="text-xs font-medium tracking-widest uppercase text-ink-muted">
              Für Praxen
            </span>
            <h2 className="text-3xl font-medium tracking-tight text-ink">NeuroEase Praxis</h2>
            <p className="text-ink-muted leading-relaxed">
              EMG- und NLG-Befunde sicher hochladen, Diagnosen mit ICD-10 strukturieren,
              Rehabilitationspläne mit Patient teilen — alles in einer ruhigen, ablenkungsarmen
              Oberfläche.
            </p>
            <ul className="flex flex-col gap-2 mt-2 text-sm text-ink-muted">
              <Bullet>Patientenprofile mit Diagnosen & Verlauf</Bullet>
              <Bullet>EMG / NLG / MRT Datei-Upload</Bullet>
              <Bullet>Reha-Pläne und sichere Nachrichten</Bullet>
            </ul>
          </div>
          <div className="flex items-center gap-2 text-ink font-medium">
            Zur Praxis <ArrowRight className="size-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </Link>

        <Link
          to="/focus"
          className="group bg-card rounded-[2rem] ring-1 ring-tray-border shadow-pebble p-8 md:p-10 flex flex-col gap-6 hover:-translate-y-0.5 hover:shadow-tray transition-all"
        >
          <div className="size-12 rounded-2xl bg-sage-soft text-sage flex items-center justify-center">
            <GraduationCap className="size-5" />
          </div>
          <div className="flex flex-col gap-3 flex-1">
            <span className="text-xs font-medium tracking-widest uppercase text-ink-muted">
              Für neurodivergente Studierende
            </span>
            <h2 className="text-3xl font-medium tracking-tight text-ink">NeuroEase Study</h2>
            <p className="text-ink-muted leading-relaxed">
              Eine reizarme Lernumgebung für ADHS, Legasthenie und Autismus. Sanfter Fokus-Timer,
              Aufgaben in winzige Schritte zerlegt, Lese-Lineal und Sensorik-Check-in.
            </p>
            <ul className="flex flex-col gap-2 mt-2 text-sm text-ink-muted">
              <Bullet>Fokus-Modus mit ausblendbarem Timer</Bullet>
              <Bullet>Aufgaben Schritt für Schritt</Bullet>
              <Bullet>Lesehilfen & Vorlesen</Bullet>
            </ul>
          </div>
          <div className="flex items-center gap-2 text-ink font-medium">
            Study öffnen <ArrowRight className="size-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </Link>
      </section>

      {/* How they connect */}
      <section className="mt-20 md:mt-28">
        <div className="max-w-2xl">
          <span className="text-sm tracking-widest uppercase text-ink-muted">
            So greifen sie ineinander
          </span>
          <h2 className="text-3xl md:text-4xl font-medium tracking-tight text-ink mt-3">
            Eine Brücke zwischen Praxis und Alltag.
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
          {[
            {
              icon: FileText,
              title: "In der Praxis",
              body: "Der/die Facharzt:ärztin lädt EMG-Befunde hoch und stellt einen Reha-Plan zusammen.",
            },
            {
              icon: Activity,
              title: "Zu Hause",
              body: "Die Patient sieht Befunde, folgt dem Plan, stellt Rückfragen über sichere Nachrichten.",
            },
            {
              icon: Heart,
              title: "Im Studium",
              body: "Junge Patient erhalten Zugang zu NeuroEase Study — Fokus & Sensorik im Lernalltag.",
            },
          ].map((p) => (
            <div
              key={p.title}
              className="bg-card rounded-3xl ring-1 ring-tray-border p-6 flex flex-col gap-3"
            >
              <div className="size-10 rounded-xl bg-sand-soft text-sand flex items-center justify-center">
                <p.icon className="size-4" />
              </div>
              <h3 className="text-xl font-medium text-ink">{p.title}</h3>
              <p className="text-ink-muted leading-relaxed text-sm">{p.body}</p>
            </div>
          ))}
        </div>
      </section>
    </PageShell>
  );
}

function Bullet({ children }: { children: React.ReactNode }) {
  return (
    <li className="flex items-start gap-2">
      <span className="mt-1.5 size-1.5 rounded-full bg-ink-muted/50 shrink-0" />
      <span>{children}</span>
    </li>
  );
}
