import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { useState } from "react";

export const Route = createFileRoute("/checkin")({
  component: CheckinPage,
  head: () => ({
    meta: [
      { title: "Sensory Check-in — NeuroEase" },
      {
        name: "description",
        content: "Notice how your mind feels and let your study space adapt to you.",
      },
    ],
  }),
});

const energy = ["Low", "Steady", "Buzzing"] as const;
const noise = ["Quiet", "Hum", "Loud"] as const;
const need = [
  "I need quiet",
  "I'm ready to work",
  "I need movement",
  "I need a small win",
] as const;

function CheckinPage() {
  const [load, setLoad] = useState(50);
  const [e, setE] = useState<(typeof energy)[number]>("Steady");
  const [n, setN] = useState<(typeof noise)[number]>("Hum");
  const [picks, setPicks] = useState<string[]>([]);
  const [done, setDone] = useState(false);

  const togglePick = (label: string) =>
    setPicks((p) => (p.includes(label) ? p.filter((x) => x !== label) : [...p, label]));

  const suggestion = (() => {
    if (load > 70 || e === "Buzzing") return "Try a 15-minute focus with the timer hidden, then a movement break.";
    if (load < 30 || e === "Low") return "Pick one tiny step from your task list. Just one — that's enough.";
    return "You're in a good window. A 25-minute focus session would land well right now.";
  })();

  return (
    <PageShell>
      <section className="pt-8 md:pt-12 pb-12 flex flex-col gap-3">
        <span className="text-sm tracking-widest uppercase text-ink-muted">Sensory Check-in</span>
        <h1 className="text-4xl md:text-5xl font-medium tracking-tight text-ink">
          How is your mind today?
        </h1>
        <p className="text-ink-muted max-w-[55ch] leading-relaxed">
          A short check-in. No right answers — just a way to notice what you need so the workspace
          can meet you there.
        </p>
      </section>

      <div className="bg-card rounded-[2.5rem] ring-1 ring-tray-border shadow-tray p-8 md:p-12 flex flex-col gap-10">
        {/* Cognitive load */}
        <div className="flex flex-col gap-4">
          <div className="flex items-baseline justify-between">
            <h2 className="text-lg font-medium text-ink">Cognitive load</h2>
            <span className="text-sm text-ink-muted">{load}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={load}
            onChange={(ev) => setLoad(Number(ev.target.value))}
            className="accent-sage"
          />
          <div className="flex justify-between text-xs text-ink-muted">
            <span>Quiet mind</span>
            <span>Overwhelmed</span>
          </div>
        </div>

        {/* Energy */}
        <SegGroup label="Energy" options={[...energy]} value={e} onChange={(v) => setE(v as typeof e)} />
        {/* Noise tolerance */}
        <SegGroup
          label="Noise tolerance right now"
          options={[...noise]}
          value={n}
          onChange={(v) => setN(v as typeof n)}
        />

        {/* Needs */}
        <div className="flex flex-col gap-4">
          <h2 className="text-lg font-medium text-ink">What do you need?</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {need.map((label) => {
              const active = picks.includes(label);
              return (
                <button
                  key={label}
                  onClick={() => togglePick(label)}
                  className={`px-5 py-4 rounded-2xl text-left transition-colors ${
                    active
                      ? "bg-ink text-primary-foreground"
                      : "bg-background ring-1 ring-tray-border text-ink hover:bg-muted"
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>

        <button
          onClick={() => setDone(true)}
          className="self-start px-7 py-3.5 rounded-full bg-sage text-white font-medium hover:opacity-90 transition-opacity"
        >
          Save check-in
        </button>

        {done && (
          <div className="rounded-2xl bg-sage-soft/60 ring-1 ring-sage/20 p-6">
            <div className="text-xs uppercase tracking-widest text-ink-muted mb-2">
              A small suggestion
            </div>
            <p className="text-lg text-ink leading-relaxed">{suggestion}</p>
          </div>
        )}
      </div>
    </PageShell>
  );
}

function SegGroup({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: string[];
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex flex-col gap-3">
      <h2 className="text-lg font-medium text-ink">{label}</h2>
      <div className="inline-flex bg-background rounded-full p-1.5 ring-1 ring-tray-border self-start">
        {options.map((o) => (
          <button
            key={o}
            onClick={() => onChange(o)}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
              value === o ? "bg-ink text-primary-foreground" : "text-ink-muted hover:text-ink"
            }`}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}
