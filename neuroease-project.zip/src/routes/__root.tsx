import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "NeuroEase — A calm study space for neurodivergent students" },
      { name: "description", content: "NeuroEase is a low-stimulation study companion for students with ADHD, dyslexia, autism and other neurological differences. Focus tools, task breakdown, reading aids, and sensory check-ins." },
      { name: "author", content: "NeuroEase" },
      { property: "og:title", content: "NeuroEase — A calm study space for neurodivergent students" },
      { property: "og:description", content: "NeuroEase is a low-stimulation study companion for students with ADHD, dyslexia, autism and other neurological differences. Focus tools, task breakdown, reading aids, and sensory check-ins." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:site", content: "@Lovable" },
      { name: "twitter:title", content: "NeuroEase — A calm study space for neurodivergent students" },
      { name: "twitter:description", content: "NeuroEase is a low-stimulation study companion for students with ADHD, dyslexia, autism and other neurological differences. Focus tools, task breakdown, reading aids, and sensory check-ins." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/2aa3a17f-a172-4b9d-b026-23ef746d597f/id-preview-ad51aea9--ee6dfca0-8808-44cb-9dc5-74cf88bc2995.lovable.app-1777112849374.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/2aa3a17f-a172-4b9d-b026-23ef746d597f/id-preview-ad51aea9--ee6dfca0-8808-44cb-9dc5-74cf88bc2995.lovable.app-1777112849374.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return <Outlet />;
}
