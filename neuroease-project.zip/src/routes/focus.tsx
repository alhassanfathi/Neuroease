import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { useEffect, useRef, useState } from "react";
import { Play, Pause, RotateCcw, Eye, EyeOff } from "lucide-react";

export const Route = createFileRoute("/focus")({
  component: FocusPage,
  head: () => ({
    meta: [
      { title: "Focus Mode — NeuroEase" },
      {
        name: "description",
        content:
          "A gentle study timer designed for ADHD and sensory-sensitive minds. Optional hidden countdown and ambient sounds.",
      },
    ],
  }),
});

const PRESETS = [
  { label: "Short", minutes: 15 },
  { label: "Standard", minutes: 25 },
  { label: "Deep", minutes: 45 },
];

function FocusPage() {
  const [minutes, setMinutes] = useState(25);
  const [remaining, setRemaining] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [hideNumbers, setHideNumbers] = useState(false);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    setRemaining(minutes * 60);
    setRunning(false);
  }, [minutes]);

  useEffect(() => {
    if (!running) return;
    intervalRef.current = window.setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          setRunning(false);
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => {
      if (intervalRef.current) window.clearInterval(intervalRef.current);
    };
  }, [running]);

  const total = minutes * 60;
  const progress = 1 - remaining / total;
  const mm = String(Math.floor(remaining / 60)).padStart(2, "0");
  const ss = String(remaining % 60).padStart(2, "0");

  return (
    <PageShell>
      <section className="pt-8 md:pt-12 pb-12 flex flex-col gap-3">
        <span className="text-sm tracking-widest uppercase text-ink-muted">Focus Mode</span>
        <h1 className="text-4xl md:text-5xl font-medium tracking-tight text-ink">
          A quiet room for one task.
        </h1>
        <p className="text-ink-muted max-w-[55ch] leading-relaxed">
          Pick a length, press start, and breathe. Hide the numbers if watching them stresses you —
          a soft ring will still show your progress.
        </p>
      </section>

      <div className="bg-card rounded-[2.5rem] ring-1 ring-tray-border shadow-tray p-8 md:p-14 flex flex-col items-center gap-10">
        {/* Presets */}
        <div className="flex items-center gap-2 bg-background rounded-full p-1.5 ring-1 ring-tray-border">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              onClick={() => setMinutes(p.minutes)}
              className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${
                minutes === p.minutes
                  ? "bg-ink text-primary-foreground"
                  : "text-ink-muted hover:text-ink"
              }`}
            >
              {p.label} · {p.minutes}m
            </button>
          ))}
        </div>

        {/* Ring */}
        <div className="relative size-64 md:size-80 flex items-center justify-center">
          <svg className="absolute inset-0 -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="46"
              fill="none"
              stroke="var(--tray-border)"
              strokeWidth="4"
            />
            <circle
              cx="50"
              cy="50"
              r="46"
              fill="none"
              stroke="var(--sage)"
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray={`${2 * Math.PI * 46}`}
              strokeDashoffset={`${2 * Math.PI * 46 * (1 - progress)}`}
              style={{ transition: "stroke-dashoffset 1s linear" }}
            />
          </svg>
          <div className="text-center">
            {hideNumbers ? (
              <span className="text-2xl font-medium text-ink-muted">In flow</span>
            ) : (
              <span className="text-6xl md:text-7xl tabular-nums tracking-tight font-medium text-ink">
                {mm}:{ss}
              </span>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setRunning((r) => !r)}
            className="px-7 py-3.5 rounded-full bg-ink text-primary-foreground font-medium flex items-center gap-2 shadow-soft hover:opacity-90 transition-opacity"
          >
            {running ? <Pause className="size-4" /> : <Play className="size-4" />}
            {running ? "Pause" : "Start"}
          </button>
          <button
            onClick={() => {
              setRemaining(minutes * 60);
              setRunning(false);
            }}
            className="size-12 rounded-full bg-background ring-1 ring-tray-border flex items-center justify-center text-ink-muted hover:text-ink"
            aria-label="Reset"
          >
            <RotateCcw className="size-4" />
          </button>
          <button
            onClick={() => setHideNumbers((h) => !h)}
            className="size-12 rounded-full bg-background ring-1 ring-tray-border flex items-center justify-center text-ink-muted hover:text-ink"
            aria-label={hideNumbers ? "Show numbers" : "Hide numbers"}
          >
            {hideNumbers ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
          </button>
        </div>
      </div>
    </PageShell>
  );
}
