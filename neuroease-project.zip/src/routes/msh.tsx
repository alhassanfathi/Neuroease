import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import {
  ArrowRight,
  BellOff,
  BookOpen,
  CheckCircle2,
  Hospital,
  Heart,
  ListTodo,
  MessageCircle,
  Stethoscope,
  Timer,
} from "lucide-react";

export const Route = createFileRoute("/msh")({
  head: () => ({
    meta: [
      { title: "MSH — Mia Suachn Hüf" },
      {
        name: "description",
        content:
          "MSH — Mia Suachn Hüf bündelt NeuroEase-Werkzeuge für Fokus, Aufgaben, Lesen und Check-in.",
      },
      { property: "og:title", content: "MSH — Mia Suachn Hüf" },
      {
        property: "og:description",
        content: "Direkter Zugang zu den NeuroEase-Unterstützungswerkzeugen von MSH.",
      },
    ],
  }),
  component: MshPage,
});

const options = [
  {
    to: "/" as const,
    title: "Start",
    body: "Zur NeuroEase-Übersicht und dem gemeinnützigen Projekt von MSH.",
    icon: Heart,
  },
  {
    to: "/focus" as const,
    title: "Fokus",
    body: "Ruhiger Fokus-Timer für konzentrierte Arbeits- und Lernphasen.",
    icon: Timer,
  },
  {
    to: "/tasks" as const,
    title: "Aufgaben",
    body: "Große Aufgaben in kleine, machbare Schritte aufteilen.",
    icon: ListTodo,
  },
  {
    to: "/read" as const,
    title: "Lesen",
    body: "Lesehilfen für eine ruhigere und klarere Textwahrnehmung.",
    icon: BookOpen,
  },
  {
    to: "/checkin" as const,
    title: "Check-in",
    body: "Kurzer Sensorik- und Tagesform-Check für mehr Selbstverständnis.",
    icon: CheckCircle2,
  },
];

const patientActions = [
  {
    title: "Mit dem Stations-Team chatten",
    body: "Wenn du hospitalisiert bist, kannst du ruhig und schriftlich mit dem zuständigen Personal schreiben.",
    icon: MessageCircle,
  },
  {
    title: "Facharzt kontaktieren",
    body: "Direkter Chat mit deinem verantwortlichen Facharzt für Fragen zu Befunden, Therapie und Reha.",
    icon: Stethoscope,
  },
  {
    title: "Pflege leise rufen",
    body: "Ein diskreter Hilferuf an die Pflege — ohne lauten, stressigen Klingelton im Zimmer.",
    icon: BellOff,
  },
  {
    title: "Krankenhaus-Verlauf",
    body: "Zeigt die letzten Krankenhäuser, Besuche und Hospitalisierungen übersichtlich an einem Ort.",
    icon: Hospital,
  },
];

function MshPage() {
  return (
    <PageShell>
      <main className="pt-8 md:pt-12 pb-20 flex flex-col gap-10">
        <header className="max-w-3xl flex flex-col gap-5">
          <span className="text-sm tracking-widest uppercase text-ink-muted">MSH — Mia Suachn Hüf</span>
          <h1 className="text-5xl md:text-[4rem] leading-[1.05] font-medium tracking-tight text-ink">
            Hilfe finden, ruhig begleitet.
          </h1>
          <p className="text-lg md:text-xl text-ink-muted leading-relaxed max-w-[58ch]">
            MSH bündelt die NeuroEase-Werkzeuge an einem Ort — für Fokus, Struktur, Lesen und
            tägliche Orientierung.
          </p>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
          {patientActions.map((action) => (
            <button
              key={action.title}
              type="button"
              className="group text-left bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble p-6 flex flex-col gap-5 hover:-translate-y-0.5 hover:shadow-tray transition-all min-h-[210px]"
            >
              <div className="size-12 rounded-2xl bg-clay-soft text-clay flex items-center justify-center">
                <action.icon className="size-5" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-medium tracking-tight text-ink">{action.title}</h2>
                <p className="text-sm text-ink-muted leading-relaxed mt-3">{action.body}</p>
              </div>
              <span className="text-sm font-medium text-ink-muted group-hover:text-ink transition-colors">
                Demnächst verfügbar
              </span>
            </button>
          ))}
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {options.map((option) => (
            <Link
              key={option.title}
              to={option.to}
              className="group bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble p-6 flex flex-col gap-5 hover:-translate-y-0.5 hover:shadow-tray transition-all min-h-[220px]"
            >
              <div className="size-12 rounded-2xl bg-sage-soft text-sage flex items-center justify-center">
                <option.icon className="size-5" />
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-medium tracking-tight text-ink">{option.title}</h2>
                <p className="text-sm text-ink-muted leading-relaxed mt-3">{option.body}</p>
              </div>
              <div className="flex items-center gap-2 text-ink font-medium">
                Öffnen <ArrowRight className="size-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))}
        </section>
      </main>
    </PageShell>
  );
}
