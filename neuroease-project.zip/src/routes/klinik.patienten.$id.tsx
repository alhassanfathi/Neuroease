import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import {
  findPatient,
  ageFromBirth,
  formatDateDe,
  type EmgFile,
  type Message,
  type Patient,
  type RehabStep,
} from "@/lib/clinic-data";
import {
  ChevronLeft,
  Upload,
  FileText,
  Send,
  Phone,
  Mail,
  Calendar,
  Plus,
  Check,
} from "lucide-react";

export const Route = createFileRoute("/klinik/patienten/$id")({
  loader: ({ params }) => {
    const patient = findPatient(params.id);
    if (!patient) throw notFound();
    return { patient };
  },
  component: PatientDetail,
  notFoundComponent: () => (
    <div className="bg-card rounded-3xl ring-1 ring-tray-border p-12 text-center">
      <h1 className="text-2xl font-medium text-ink">Patient nicht gefunden</h1>
      <Link to="/klinik/patienten" className="mt-4 inline-block text-ink-muted hover:text-ink">
        Zurück zur Liste
      </Link>
    </div>
  ),
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData
          ? `${loaderData.patient.firstName} ${loaderData.patient.lastName} — NeuroEase Praxis`
          : "Patient — NeuroEase Praxis",
      },
    ],
  }),
});

type Tab = "uebersicht" | "befunde" | "reha" | "nachrichten";

function PatientDetail() {
  const { patient: initial } = Route.useLoaderData() as { patient: Patient };
  const [tab, setTab] = useState<Tab>("uebersicht");
  const [rehab, setRehab] = useState<RehabStep[]>(initial.rehab);
  const [messages, setMessages] = useState<Message[]>(initial.messages);
  const [draft, setDraft] = useState("");
  const [files, setFiles] = useState<EmgFile[]>(initial.files);

  const toggleStep = (id: string) =>
    setRehab((r) => r.map((s) => (s.id === id ? { ...s, done: !s.done } : s)));

  const send = () => {
    if (!draft.trim()) return;
    setMessages((m) => [
      ...m,
      { id: crypto.randomUUID(), from: "doctor", text: draft, at: new Date().toISOString() },
    ]);
    setDraft("");
  };

  const onUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFiles((curr) => [
      ...curr,
      {
        id: crypto.randomUUID(),
        name: f.name,
        kind: "Bericht",
        date: new Date().toISOString(),
        sizeKb: Math.round(f.size / 1024),
      },
    ]);
    e.target.value = "";
  };

  return (
    <div className="flex flex-col gap-6">
      <Link
        to="/klinik/patienten"
        className="inline-flex items-center gap-1 text-sm text-ink-muted hover:text-ink"
      >
        <ChevronLeft className="size-4" /> Zurück zur Liste
      </Link>

      {/* Header card */}
      <header className="bg-card rounded-3xl ring-1 ring-tray-border shadow-tray p-6 md:p-8 flex flex-col md:flex-row md:items-center gap-6">
        <div className="size-16 rounded-2xl bg-sage-soft text-sage flex items-center justify-center text-xl font-medium shrink-0">
          {initial.firstName[0]}
          {initial.lastName[0]}
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-3xl font-medium tracking-tight text-ink">
            {initial.firstName} {initial.lastName}
          </h1>
          <div className="text-sm text-ink-muted mt-1">
            Geb. {formatDateDe(initial.birthDate)} · {ageFromBirth(initial.birthDate)} Jahre ·{" "}
            {initial.insurance} · {initial.insuranceNumber}
          </div>
          <div className="flex flex-wrap gap-x-5 gap-y-1 mt-3 text-sm text-ink-muted">
            <span className="inline-flex items-center gap-1.5">
              <Mail className="size-3.5" /> {initial.email}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Phone className="size-3.5" /> {initial.phone}
            </span>
          </div>
        </div>
        <div className="flex flex-col gap-2 md:items-end">
          <span className="text-xs uppercase tracking-widest text-ink-muted">Hauptdiagnose</span>
          <div className="text-right">
            <div className="font-medium text-ink">{initial.diagnosis.primary.label}</div>
            <div className="text-xs text-ink-muted font-mono">{initial.diagnosis.primary.code}</div>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="flex gap-1 bg-card rounded-full p-1.5 ring-1 ring-tray-border self-start overflow-x-auto">
        {(
          [
            ["uebersicht", "Übersicht"],
            ["befunde", "Befunde"],
            ["reha", "Reha-Plan"],
            ["nachrichten", "Nachrichten"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              tab === id
                ? "bg-ink text-primary-foreground"
                : "text-ink-muted hover:text-ink"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {tab === "uebersicht" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <section className="bg-card rounded-3xl ring-1 ring-tray-border p-6 flex flex-col gap-4">
            <h2 className="text-lg font-medium text-ink">Diagnosen</h2>
            <div className="flex flex-col gap-3">
              <div className="p-4 rounded-2xl bg-background ring-1 ring-tray-border">
                <div className="text-xs uppercase tracking-widest text-ink-muted">Primär</div>
                <div className="text-ink font-medium mt-1">{initial.diagnosis.primary.label}</div>
                <div className="text-xs text-ink-muted font-mono">
                  ICD-10: {initial.diagnosis.primary.code}
                </div>
              </div>
              {initial.diagnosis.secondary.map((d) => (
                <div key={d.code} className="p-4 rounded-2xl bg-background ring-1 ring-tray-border">
                  <div className="text-xs uppercase tracking-widest text-ink-muted">Sekundär</div>
                  <div className="text-ink mt-1">{d.label}</div>
                  <div className="text-xs text-ink-muted font-mono">ICD-10: {d.code}</div>
                </div>
              ))}
            </div>
          </section>
          <section className="bg-card rounded-3xl ring-1 ring-tray-border p-6 flex flex-col gap-4">
            <h2 className="text-lg font-medium text-ink">Termine</h2>
            <div className="flex flex-col gap-3">
              {initial.appointments.length === 0 && (
                <p className="text-ink-muted text-sm">Keine geplanten Termine.</p>
              )}
              {initial.appointments.map((a) => (
                <div
                  key={a.id}
                  className="p-4 rounded-2xl bg-background ring-1 ring-tray-border flex items-start gap-3"
                >
                  <Calendar className="size-4 text-ink-muted mt-1" />
                  <div className="flex-1">
                    <div className="text-ink font-medium">{a.type}</div>
                    <div className="text-xs text-ink-muted">{a.location}</div>
                    <div className="text-sm text-ink-muted mt-1">{formatDateDe(a.date, true)}</div>
                  </div>
                </div>
              ))}
            </div>
            <h3 className="text-sm font-medium text-ink mt-4">Notiz für die Akte</h3>
            <p className="text-sm text-ink-muted leading-relaxed bg-background rounded-2xl p-4 ring-1 ring-tray-border">
              {initial.notes}
            </p>
          </section>
        </div>
      )}

      {tab === "befunde" && (
        <section className="bg-card rounded-3xl ring-1 ring-tray-border p-6 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-ink">Befunde & Dateien</h2>
            <label className="px-4 py-2.5 rounded-full bg-ink text-primary-foreground text-sm font-medium cursor-pointer inline-flex items-center gap-2">
              <Upload className="size-4" /> Datei hochladen
              <input type="file" className="hidden" onChange={onUpload} />
            </label>
          </div>
          <p className="text-xs text-ink-muted">
            Prototyp: Dateien werden lokal in dieser Sitzung gespeichert. Im Produktivbetrieb
            verschlüsselt in Lovable Cloud Storage.
          </p>
          <div className="flex flex-col divide-y divide-tray-border">
            {files.map((f) => (
              <div key={f.id} className="py-3 flex items-center gap-4">
                <div className="size-10 rounded-xl bg-clay-soft text-clay flex items-center justify-center">
                  <FileText className="size-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-ink truncate">{f.name}</div>
                  <div className="text-xs text-ink-muted">
                    {f.kind} · {formatDateDe(f.date)} · {f.sizeKb} KB
                  </div>
                </div>
                <button className="text-sm text-ink-muted hover:text-ink">An Patient senden</button>
              </div>
            ))}
            {files.length === 0 && (
              <div className="py-8 text-center text-ink-muted text-sm">Noch keine Befunde.</div>
            )}
          </div>
        </section>
      )}

      {tab === "reha" && (
        <section className="bg-card rounded-3xl ring-1 ring-tray-border p-6 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-ink">Rehabilitationsplan</h2>
            <button className="px-4 py-2.5 rounded-full bg-ink text-primary-foreground text-sm font-medium inline-flex items-center gap-2">
              <Plus className="size-4" /> Schritt hinzufügen
            </button>
          </div>
          <div className="flex flex-col gap-3">
            {rehab.map((s) => (
              <div
                key={s.id}
                className="p-5 rounded-2xl bg-background ring-1 ring-tray-border flex items-start gap-4"
              >
                <button
                  onClick={() => toggleStep(s.id)}
                  className={`mt-1 shrink-0 size-6 rounded-md flex items-center justify-center transition-colors ${
                    s.done ? "bg-sage text-white" : "bg-card ring-1 ring-tray-border"
                  }`}
                  aria-label={s.done ? "Als offen markieren" : "Als erledigt markieren"}
                >
                  {s.done && <Check className="size-4" />}
                </button>
                <div className="flex-1">
                  <div className={`font-medium ${s.done ? "text-ink-muted line-through" : "text-ink"}`}>
                    {s.title}
                  </div>
                  <p className="text-sm text-ink-muted leading-relaxed mt-1">{s.description}</p>
                  <div className="text-xs text-ink-muted mt-2">Frequenz: {s.frequency}</div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {tab === "nachrichten" && (
        <section className="bg-card rounded-3xl ring-1 ring-tray-border p-6 flex flex-col gap-4 min-h-[400px]">
          <h2 className="text-lg font-medium text-ink">Nachrichten</h2>
          <div className="flex-1 flex flex-col gap-3 overflow-y-auto max-h-[420px] pr-1">
            {messages.length === 0 && (
              <p className="text-sm text-ink-muted">Noch keine Nachrichten ausgetauscht.</p>
            )}
            {messages.map((m) => (
              <div
                key={m.id}
                className={`max-w-[85%] p-4 rounded-2xl ${
                  m.from === "doctor"
                    ? "bg-ink text-primary-foreground self-end"
                    : "bg-background ring-1 ring-tray-border self-start"
                }`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>
                <div
                  className={`text-xs mt-2 ${m.from === "doctor" ? "opacity-70" : "text-ink-muted"}`}
                >
                  {m.from === "doctor" ? "Dr. Weber" : `${initial.firstName} ${initial.lastName}`} ·{" "}
                  {formatDateDe(m.at, true)}
                </div>
              </div>
            ))}
          </div>
          <div className="flex gap-2 pt-3 border-t border-tray-border">
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Nachricht an Patient schreiben…"
              rows={2}
              className="flex-1 px-4 py-3 rounded-2xl bg-background ring-1 ring-tray-border text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none"
            />
            <button
              onClick={send}
              className="px-5 rounded-2xl bg-ink text-primary-foreground font-medium inline-flex items-center gap-2 self-stretch"
            >
              <Send className="size-4" />
            </button>
          </div>
        </section>
      )}
    </div>
  );
}
