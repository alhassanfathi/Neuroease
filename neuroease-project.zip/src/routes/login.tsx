import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Mail, Lock, UserRound, Building2, Stethoscope, Hospital, HeartPulse } from "lucide-react";
import { z } from "zod";
import { PageShell } from "@/components/PageShell";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import type { Enums } from "@/integrations/supabase/types";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Login — NeuroEase" },
      {
        name: "description",
        content: "Login für Patient, Arzt, Klinik, Krankenhaus und Pflegepersonal in NeuroEase.",
      },
    ],
  }),
  component: LoginPage,
});

type Role = Enums<"app_role">;
type Mode = "login" | "signup";

const roleOptions: Array<{ value: Role; label: string; body: string; icon: typeof UserRound }> = [
  { value: "patient", label: "Patient", body: "Eigene Hilfe, Chats und Klinikverlauf", icon: UserRound },
  { value: "arzt", label: "Arzt / Facharzt", body: "Patienten begleiten und Befunde teilen", icon: Stethoscope },
  { value: "klinik", label: "Klinik", body: "Praxis- und Klinikabläufe verwalten", icon: Building2 },
  { value: "hospital", label: "Hospital", body: "Stationäre Versorgung koordinieren", icon: Hospital },
  { value: "nurse", label: "Nurses / Pflege", body: "Leise Hilfeanfragen und Stationschat", icon: HeartPulse },
];

const emailSchema = z.object({
  email: z.string().trim().email("Bitte gib eine gültige E-Mail ein.").max(255),
  password: z.string().min(6, "Das Passwort braucht mindestens 6 Zeichen.").max(128),
  fullName: z.string().trim().max(120).optional(),
  organization: z.string().trim().max(120).optional(),
});

function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("login");
  const [role, setRole] = useState<Role>("patient");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [organization, setOrganization] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const selectedRole = useMemo(() => roleOptions.find((item) => item.value === role), [role]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session?.user) void provisionAccount(data.session.user.id, data.session.user.email ?? "");
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) void provisionAccount(session.user.id, session.user.email ?? "");
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  const provisionAccount = async (userId: string, userEmail: string) => {
    const pendingRole = (localStorage.getItem("neuroease_pending_role") as Role | null) ?? role;
    const pendingName = localStorage.getItem("neuroease_pending_name") ?? fullName;
    const pendingOrganization = localStorage.getItem("neuroease_pending_organization") ?? organization;

    await supabase.from("profiles").upsert(
      {
        user_id: userId,
        full_name: pendingName || userEmail.split("@")[0],
        organization_name: pendingOrganization || null,
      },
      { onConflict: "user_id" },
    );

    if (pendingRole === "patient") {
      await supabase.from("user_roles").upsert({ user_id: userId, role: "patient" }, { onConflict: "user_id,role" });
    } else {
      await supabase.from("role_requests").upsert(
        {
          user_id: userId,
          requested_role: pendingRole,
          organization_name: pendingOrganization || null,
          note: "Rollenanfrage aus dem Login-Interface",
        },
        { onConflict: "id" },
      );
    }

    localStorage.removeItem("neuroease_pending_role");
    localStorage.removeItem("neuroease_pending_name");
    localStorage.removeItem("neuroease_pending_organization");
  };

  const rememberRole = () => {
    localStorage.setItem("neuroease_pending_role", role);
    localStorage.setItem("neuroease_pending_name", fullName);
    localStorage.setItem("neuroease_pending_organization", organization);
  };

  const handleEmailSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setMessage("");

    const parsed = emailSchema.safeParse({ email, password, fullName, organization });
    if (!parsed.success) {
      setMessage(parsed.error.issues[0]?.message ?? "Bitte prüfe deine Eingaben.");
      return;
    }

    setLoading(true);
    rememberRole();

    const result =
      mode === "signup"
        ? await supabase.auth.signUp({
            email: parsed.data.email,
            password: parsed.data.password,
            options: { emailRedirectTo: window.location.origin + "/login" },
          })
        : await supabase.auth.signInWithPassword({ email: parsed.data.email, password: parsed.data.password });

    setLoading(false);

    if (result.error) {
      setMessage(result.error.message);
      return;
    }

    if (mode === "signup" && !result.data.session) {
      setMessage("Bitte bestätige deine E-Mail. Danach wird dein Zugang eingerichtet.");
      return;
    }

    if (result.data.user) await provisionAccount(result.data.user.id, result.data.user.email ?? parsed.data.email);
    navigate({ to: role === "patient" ? "/msh" : "/klinik" });
  };

  const handleGoogle = async () => {
    setMessage("");
    setLoading(true);
    rememberRole();
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/login" });
    setLoading(false);

    if (result.error) setMessage(result.error.message);
  };

  return (
    <PageShell>
      <main className="grid min-h-[calc(100vh-120px)] grid-cols-1 lg:grid-cols-12 gap-8 py-8 md:py-14 items-center">
        <section className="lg:col-span-5 flex flex-col gap-6">
          <span className="text-sm tracking-widest uppercase text-ink-muted">NeuroEase Zugang</span>
          <h1 className="text-5xl md:text-[4rem] leading-[1.05] font-medium tracking-tight text-ink">
            Ruhiger Login für Versorgung und Hilfe.
          </h1>
          <p className="text-lg text-ink-muted leading-relaxed">
            Wähle zuerst deine Rolle. Patientenzugänge starten direkt, medizinische Rollen werden sicher geprüft.
          </p>
        </section>

        <section className="lg:col-span-7 bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble p-5 md:p-7 flex flex-col gap-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3">
            {roleOptions.map((item) => (
              <button
                key={item.value}
                type="button"
                onClick={() => setRole(item.value)}
                className={`text-left rounded-2xl ring-1 p-4 min-h-[132px] transition-all ${
                  role === item.value
                    ? "bg-ink text-primary-foreground ring-ink"
                    : "bg-background text-ink ring-tray-border hover:bg-muted"
                }`}
              >
                <item.icon className="size-5 mb-3" />
                <div className="text-sm font-medium">{item.label}</div>
                <div className={`text-xs leading-relaxed mt-2 ${role === item.value ? "text-primary-foreground/75" : "text-ink-muted"}`}>
                  {item.body}
                </div>
              </button>
            ))}
          </div>

          <div className="flex gap-1 bg-background rounded-full p-1 ring-1 ring-tray-border self-start">
            {(["login", "signup"] as const).map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setMode(item)}
                className={`px-4 py-2 rounded-full text-sm font-medium ${
                  mode === item ? "bg-ink text-primary-foreground" : "text-ink-muted hover:text-ink"
                }`}
              >
                {item === "login" ? "Anmelden" : "Registrieren"}
              </button>
            ))}
          </div>

          <form onSubmit={handleEmailSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mode === "signup" && (
              <>
                <label className="flex flex-col gap-2 text-sm font-medium text-ink">
                  Vollständiger Name
                  <input value={fullName} onChange={(e) => setFullName(e.target.value)} className="rounded-2xl bg-background ring-1 ring-tray-border px-4 py-3 text-sm outline-none focus:ring-ink" />
                </label>
                <label className="flex flex-col gap-2 text-sm font-medium text-ink">
                  Klinik / Hospital / Organisation
                  <input value={organization} onChange={(e) => setOrganization(e.target.value)} className="rounded-2xl bg-background ring-1 ring-tray-border px-4 py-3 text-sm outline-none focus:ring-ink" />
                </label>
              </>
            )}
            <label className="flex flex-col gap-2 text-sm font-medium text-ink">
              E-Mail
              <span className="flex items-center gap-2 rounded-2xl bg-background ring-1 ring-tray-border px-4 py-3 focus-within:ring-ink">
                <Mail className="size-4 text-ink-muted" />
                <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" className="w-full bg-transparent text-sm outline-none" />
              </span>
            </label>
            <label className="flex flex-col gap-2 text-sm font-medium text-ink">
              Passwort
              <span className="flex items-center gap-2 rounded-2xl bg-background ring-1 ring-tray-border px-4 py-3 focus-within:ring-ink">
                <Lock className="size-4 text-ink-muted" />
                <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" className="w-full bg-transparent text-sm outline-none" />
              </span>
            </label>

            <div className="md:col-span-2 flex flex-col sm:flex-row gap-3">
              <button type="submit" disabled={loading} className="flex-1 rounded-full bg-ink text-primary-foreground px-5 py-3 text-sm font-medium disabled:opacity-60">
                {mode === "login" ? `Als ${selectedRole?.label} anmelden` : `Als ${selectedRole?.label} registrieren`}
              </button>
              <button type="button" disabled={loading} onClick={handleGoogle} className="flex-1 rounded-full bg-background ring-1 ring-tray-border text-ink px-5 py-3 text-sm font-medium hover:bg-muted disabled:opacity-60">
                Mit Google fortfahren
              </button>
            </div>
          </form>

          {message && <p className="rounded-2xl bg-sand-soft px-4 py-3 text-sm text-sand">{message}</p>}
        </section>
      </main>
    </PageShell>
  );
}