import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";

export const Route = createFileRoute("/read")({
  component: ReadPage,
  head: () => ({
    meta: [
      { title: "Reading Aids — NeuroEase" },
      {
        name: "description",
        content:
          "Reading ruler, dyslexia-friendly font, adjustable spacing and text-to-speech for easier studying.",
      },
    ],
  }),
});

const SAMPLE = `Neurons are the building blocks of the nervous system. Each one receives signals through branches called dendrites, processes them in the cell body, and passes them on through a long fibre called the axon. The point where one neuron meets another is called a synapse. When you learn something new, the connections at certain synapses grow stronger. This is why practice matters more than pressure, and why rest is part of the work.`;

function ReadPage() {
  const [dyslexic, setDyslexic] = useState(false);
  const [relaxed, setRelaxed] = useState(true);
  const [size, setSize] = useState(18);
  const [rulerY, setRulerY] = useState<number | null>(null);
  const [speaking, setSpeaking] = useState(false);
  const articleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    return () => {
      if (typeof window !== "undefined") window.speechSynthesis?.cancel();
    };
  }, []);

  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = articleRef.current?.getBoundingClientRect();
    if (!rect) return;
    setRulerY(e.clientY - rect.top);
  };

  const speak = () => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }
    const u = new SpeechSynthesisUtterance(SAMPLE);
    u.rate = 0.95;
    u.onend = () => setSpeaking(false);
    window.speechSynthesis.speak(u);
    setSpeaking(true);
  };

  return (
    <PageShell>
      <section className="pt-8 md:pt-12 pb-12 flex flex-col gap-3">
        <span className="text-sm tracking-widest uppercase text-ink-muted">Reading Aids</span>
        <h1 className="text-4xl md:text-5xl font-medium tracking-tight text-ink">
          Make any text easier on your eyes.
        </h1>
        <p className="text-ink-muted max-w-[55ch] leading-relaxed">
          Hover over the passage to see the reading ruler. Adjust spacing, font, and size — or have
          it read aloud.
        </p>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls */}
        <aside className="lg:col-span-4 bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble p-6 flex flex-col gap-6 h-fit">
          <h2 className="text-sm font-medium uppercase tracking-widest text-ink-muted">Settings</h2>

          <Toggle label="Dyslexia-friendly font" value={dyslexic} onChange={setDyslexic} />
          <Toggle label="Relaxed spacing" value={relaxed} onChange={setRelaxed} />

          <div className="flex flex-col gap-2">
            <label className="text-sm text-ink-muted">Text size · {size}px</label>
            <input
              type="range"
              min={14}
              max={28}
              value={size}
              onChange={(e) => setSize(Number(e.target.value))}
              className="accent-ink"
            />
          </div>

          <button
            onClick={speak}
            className="px-5 py-3 rounded-full bg-ink text-primary-foreground font-medium flex items-center justify-center gap-2"
          >
            {speaking ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
            {speaking ? "Stop reading" : "Read aloud"}
          </button>
        </aside>

        {/* Article */}
        <article
          ref={articleRef}
          onMouseMove={onMove}
          onMouseLeave={() => setRulerY(null)}
          className="lg:col-span-8 bg-card rounded-3xl ring-1 ring-tray-border shadow-tray p-8 md:p-12 relative overflow-hidden cursor-text"
        >
          {rulerY !== null && (
            <div
              className="absolute inset-x-0 h-12 bg-sand-soft/70 border-y border-sand/30 pointer-events-none transition-none"
              style={{ top: rulerY - 24 }}
            />
          )}
          <div
            className={`relative text-ink ${dyslexic ? "reading-dyslexic" : ""} ${relaxed ? "reading-relaxed" : ""}`}
            style={{ fontSize: `${size}px`, lineHeight: relaxed ? 1.85 : 1.55 }}
          >
            <p>{SAMPLE}</p>
          </div>
        </article>
      </div>
    </PageShell>
  );
}

function Toggle({
  label,
  value,
  onChange,
}: {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!value)}
      className="flex items-center justify-between gap-3 text-left"
    >
      <span className="text-ink">{label}</span>
      <span
        className={`w-11 h-6 rounded-full p-0.5 flex transition-colors ${
          value ? "bg-sage justify-end" : "bg-muted justify-start"
        }`}
      >
        <span className="size-5 rounded-full bg-card shadow-soft" />
      </span>
    </button>
  );
}
