import { createFileRoute, Link } from "@tanstack/react-router";
import { patients, formatDateDe } from "@/lib/clinic-data";

export const Route = createFileRoute("/klinik/nachrichten")({
  component: NachrichtenPage,
  head: () => ({ meta: [{ title: "Nachrichten — NeuroEase Praxis" }] }),
});

function NachrichtenPage() {
  const threads = patients
    .filter((p) => p.messages.length > 0)
    .map((p) => ({
      patient: p,
      last: p.messages[p.messages.length - 1],
    }))
    .sort((a, b) => b.last.at.localeCompare(a.last.at));

  return (
    <div className="flex flex-col gap-6">
      <header className="flex flex-col gap-2">
        <span className="text-sm tracking-widest uppercase text-ink-muted">Nachrichten</span>
        <h1 className="text-3xl md:text-4xl font-medium tracking-tight text-ink">Posteingang</h1>
      </header>

      <div className="bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble divide-y divide-tray-border">
        {threads.map(({ patient: p, last }) => (
          <Link
            key={p.id}
            to="/klinik/patienten/$id"
            params={{ id: p.id }}
            className="px-6 py-5 flex items-start gap-4 hover:bg-muted transition-colors"
          >
            <div className="size-10 rounded-full bg-sage-soft text-sage flex items-center justify-center font-medium text-sm shrink-0">
              {p.firstName[0]}
              {p.lastName[0]}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <span className="font-medium text-ink">
                  {p.firstName} {p.lastName}
                </span>
                <span className="text-xs text-ink-muted">{formatDateDe(last.at, true)}</span>
              </div>
              <p className="text-sm text-ink-muted mt-1 line-clamp-2">
                <span className="text-ink-muted/70">
                  {last.from === "patient" ? "Patient: " : "Sie: "}
                </span>
                {last.text}
              </p>
            </div>
          </Link>
        ))}
        {threads.length === 0 && (
          <div className="px-6 py-12 text-center text-ink-muted">Keine Nachrichten.</div>
        )}
      </div>
    </div>
  );
}
