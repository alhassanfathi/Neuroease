import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { patients, ageFromBirth, formatDateDe } from "@/lib/clinic-data";
import { Search, Plus } from "lucide-react";

export const Route = createFileRoute("/klinik/patienten/")({
  component: PatientList,
  head: () => ({ meta: [{ title: "Patient — NeuroEase Praxis" }] }),
});

const statusTone: Record<string, string> = {
  Aktiv: "bg-sage-soft text-sage",
  "In Beobachtung": "bg-sand-soft text-sand",
  Abgeschlossen: "bg-muted text-ink-muted",
};

function PatientList() {
  const [q, setQ] = useState("");
  const filtered = patients.filter((p) => {
    if (!q.trim()) return true;
    const s = q.toLowerCase();
    return (
      p.firstName.toLowerCase().includes(s) ||
      p.lastName.toLowerCase().includes(s) ||
      p.diagnosis.primary.label.toLowerCase().includes(s) ||
      p.diagnosis.primary.code.toLowerCase().includes(s)
    );
  });

  return (
    <div className="flex flex-col gap-6">
      <header className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div className="flex flex-col gap-2">
          <span className="text-sm tracking-widest uppercase text-ink-muted">Patient</span>
          <h1 className="text-3xl md:text-4xl font-medium tracking-tight text-ink">
            Alle Patient
          </h1>
        </div>
        <button className="self-start md:self-auto px-5 py-3 rounded-full bg-ink text-primary-foreground font-medium inline-flex items-center gap-2">
          <Plus className="size-4" /> Patient anlegen
        </button>
      </header>

      <div className="bg-card rounded-2xl ring-1 ring-tray-border p-2 flex items-center gap-2">
        <Search className="size-4 text-ink-muted ml-3" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Nach Name, Diagnose oder ICD-10 suchen…"
          className="flex-1 bg-transparent px-2 py-2 text-sm focus:outline-none"
        />
      </div>

      <div className="bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble overflow-hidden">
        <div className="hidden md:grid grid-cols-12 gap-4 px-6 py-3 text-xs uppercase tracking-widest text-ink-muted border-b border-tray-border bg-background">
          <div className="col-span-4">Name</div>
          <div className="col-span-3">Diagnose</div>
          <div className="col-span-2">Status</div>
          <div className="col-span-3">Letzter Besuch</div>
        </div>
        <div className="flex flex-col divide-y divide-tray-border">
          {filtered.map((p) => (
            <Link
              key={p.id}
              to="/klinik/patienten/$id"
              params={{ id: p.id }}
              className="grid grid-cols-1 md:grid-cols-12 gap-2 md:gap-4 px-6 py-4 hover:bg-muted transition-colors"
            >
              <div className="md:col-span-4 flex items-center gap-3">
                <div className="size-10 rounded-full bg-sage-soft text-sage flex items-center justify-center font-medium text-sm">
                  {p.firstName[0]}
                  {p.lastName[0]}
                </div>
                <div className="min-w-0">
                  <div className="font-medium text-ink truncate">
                    {p.lastName}, {p.firstName}
                  </div>
                  <div className="text-xs text-ink-muted">
                    {ageFromBirth(p.birthDate)} J. · {p.insurance}
                  </div>
                </div>
              </div>
              <div className="md:col-span-3 flex flex-col justify-center">
                <span className="text-sm text-ink truncate">{p.diagnosis.primary.label}</span>
                <span className="text-xs text-ink-muted font-mono">{p.diagnosis.primary.code}</span>
              </div>
              <div className="md:col-span-2 flex items-center">
                <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${statusTone[p.status]}`}>
                  {p.status}
                </span>
              </div>
              <div className="md:col-span-3 flex items-center text-sm text-ink-muted">
                {formatDateDe(p.lastVisit)}
              </div>
            </Link>
          ))}
          {filtered.length === 0 && (
            <div className="px-6 py-12 text-center text-ink-muted">Keine Treffer.</div>
          )}
        </div>
      </div>
    </div>
  );
}
