import { createFileRoute, Link } from "@tanstack/react-router";
import { patients, formatDateDe } from "@/lib/clinic-data";
import { Calendar } from "lucide-react";

export const Route = createFileRoute("/klinik/termine")({
  component: TerminePage,
  head: () => ({ meta: [{ title: "Termine — NeuroEase Praxis" }] }),
});

function TerminePage() {
  const all = patients
    .flatMap((p) => p.appointments.map((a) => ({ ...a, patient: p })))
    .sort((a, b) => a.date.localeCompare(b.date));

  return (
    <div className="flex flex-col gap-6">
      <header className="flex flex-col gap-2">
        <span className="text-sm tracking-widest uppercase text-ink-muted">Termine</span>
        <h1 className="text-3xl md:text-4xl font-medium tracking-tight text-ink">
          Geplante Termine
        </h1>
      </header>

      <div className="bg-card rounded-3xl ring-1 ring-tray-border shadow-pebble divide-y divide-tray-border">
        {all.map((a) => (
          <Link
            key={a.id}
            to="/klinik/patienten/$id"
            params={{ id: a.patient.id }}
            className="px-6 py-5 flex items-center gap-4 hover:bg-muted transition-colors"
          >
            <div className="size-12 rounded-2xl bg-sand-soft text-sand flex items-center justify-center">
              <Calendar className="size-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-ink">
                {a.patient.firstName} {a.patient.lastName}
              </div>
              <div className="text-sm text-ink-muted">
                {a.type} · {a.location}
              </div>
            </div>
            <div className="text-sm text-ink-muted text-right shrink-0">
              {formatDateDe(a.date, true)}
            </div>
          </Link>
        ))}
        {all.length === 0 && (
          <div className="px-6 py-12 text-center text-ink-muted">Keine Termine geplant.</div>
        )}
      </div>
    </div>
  );
}
